//! Bit-packed fingerprint storage.
//!
//! # Purpose
//!
//! [`FingerprintTable`] is the physical storage layer of every [`CuckooFilter`]. It stores
//! fingerprints at arbitrary bit widths (1–64 bits) in a flat byte buffer,
//! without byte alignment. This allows, for example, 12-bit fingerprints to be packed at
//! 66% of the space that 16-bit (byte-aligned) storage would consume.
//!
//! # Memory layout
//!
//! Fingerprints are packed contiguously, LSB-first. To read or write a fingerprint, the code
//! loads an unaligned window, shifts, and masks — an 8-byte `u64` window while
//! `fingerprint_bits <= 56` (a shifted field then fits in 63 bits), a 16-byte `u128`
//! window above (a sub-byte-aligned 64-bit field spans up to 9 bytes):
//!
//! ```text
//! bit offset = (bucket * bucket_size + slot) * fingerprint_bits
//! byte index = bit_offset / 8
//! shift      = bit_offset % 8
//! value      = (window_at(byte_index) >> shift) & mask
//! ```
//!
//! Sixteen bytes of padding are appended to the allocation so that either window stays
//! within bounds regardless of alignment.
//!
//! # Security
//!
//! No secret data flows through this module. All reads and writes are unconditional; there
//! are no data-dependent branches that could leak timing information about fingerprint values.
//!
//! [`CuckooFilter`]: crate::CuckooFilter

/// Bit-packed fingerprint storage for a cuckoo filter.
///
/// All fingerprint widths from 1 to 64 bits are supported. Fingerprints are stored without
/// byte alignment; the internal representation loads/stores `u64` windows at the byte level
/// up to 56-bit widths and `u128` windows above (see Design rationale).
///
/// # Layout
///
/// Fingerprints are packed contiguously, LSB-first both within and across bytes. There are
/// no per-bucket headers, no inter-slot padding, and no byte alignment between fingerprints.
/// Example with `fingerprint_bits = 12`, `bucket_size = 4`:
///
/// ```text
/// byte:   |   0    |   1    |   2    |   3    |   4    | ...
/// bits:   |76543210|76543210|76543210|76543210|76543210|
/// fp #0:   <----- 12 ----->                              bits  0..11
/// fp #1:                       <----- 12 ----->          bits 12..23
/// fp #2:                                        <-- 12   bits 24..35 (crosses byte 3 → 4)
/// ```
///
/// # Design rationale
///
/// - **Flat `Vec<u8>` over `Vec<u16>` / `Vec<u32>` / `bitvec`.** A `u16` slot array wastes
///   33% on 12-bit fingerprints; a `u32` array, 167%. `bitvec` adds a dependency and a
///   feature-gated layout that breaks stable (de)serialisation. The flat buffer gives
///   minimum memory, a single allocation (a 2-bucket probe typically touches 1–2 cache
///   lines), and a layout that *is* the on-disk wire format. The only cost is unaligned
///   access, which is free on x86_64 and aarch64.
///
/// - **Width-split load window: `u64` up to 56 bits, `u128` above.** A sub-byte-aligned
///   field spans `bit_shift` (≤ 7) plus `fingerprint_bits` bits of its window, so up to 56
///   bits the original single 8-byte load still covers it (≤ 63 bits) at one `MOV` +
///   `SHR` — and the cuckoo-filter throughput benches, which hot-loop `read`/`write`,
///   keep their pre-widening cost at every legacy width. Past 56 bits the field can span
///   9 bytes; no mainstream ISA has a 9-byte load, so that path loads a 16-byte `u128`
///   window (register pair on x86-64 — the cost of genuinely wide fingerprints, paid only
///   by them). The branch predicate `fingerprint_bits <= 56` is a per-table constant, so
///   the predictor resolves it for free inside any loop over one table.
///
/// - **`u128` arithmetic on the wide path.** Its mask is built as
///   `(1u128 << fingerprint_bits) - 1`: at `fingerprint_bits == 64`, `1u64 << 64` would be
///   undefined behaviour in Rust (shift ≥ bit-width), whereas `1u128 << 64` is well-defined
///   and yields the correct `0xFFFF_FFFF_FFFF_FFFF`; the final cast back to `u64` is
///   lossless because `mask ≤ 2⁶⁴ − 1`. The narrow path stays in `u64` throughout
///   (`fingerprint_bits ≤ 56 < 64`, so its mask shift cannot overflow).
///
/// - **16-byte tail padding either way.** The padding allocated by [`new`](Self::new)
///   keeps both `data[byte_pos..byte_pos + 8]` and `..+ 16` in-bounds for every legal
///   `(bucket, slot)`, so the `try_into` in [`read`](Self::read) / [`write`](Self::write)
///   cannot fail — the `expect` documents this invariant, not an error path.
///
/// - **LSB-first / little-endian packing.** Higher byte indices map to higher bits of the
///   loaded window, so extraction is `(val >> bit_shift) & mask` and insertion is
///   `val |= (fp & mask) << bit_shift` with `bit_shift = bit_pos % 8` in both directions.
///   Byte-crossing fields need no special case; an MSB-first layout would require
///   splitting them across two masks with inverted shifts. Every Rust tier-1 target is
///   little-endian, so `from_le_bytes` / `to_le_bytes` compile to plain unaligned
///   loads/stores, and the on-memory layout is host-independent and serialisation-stable.
///
/// # Invariants (caller-enforced)
///
/// These are not checked by `FingerprintTable` itself:
///
/// - `fingerprint_bits ∈ 1..=64` — enforced upstream in `validate_common_params`
///   (in `filter.rs`); every public constructor path goes through it.
/// - Fingerprint value `0` is reserved to mean "empty slot"; the hash layer must never
///   produce `0` for a real key. [`insert`](Self::insert)
///   and [`delete`](Self::delete) panic on
///   a zero input, but [`read`](Self::read) and
///   [`write`](Self::write) do not — callers must uphold the
///   invariant there themselves.
/// - `bucket < num_buckets` and `slot < bucket_size` — checked only by the
///   assertions in the read/write primitives, which panic out of range.
#[derive(Clone)]
pub struct FingerprintTable {
    /// Raw fingerprint data: `⌈num_buckets · bucket_size · fingerprint_bits / 8⌉ + 16` bytes (16 bytes padding).
    data: Vec<u8>,
    /// Total number of buckets.
    num_buckets: u32,
    /// Slots (fingerprints) per bucket.
    bucket_size: u32,
    /// Bit width of each fingerprint (1–64).
    fingerprint_bits: u32,
}

impl FingerprintTable {
    /// Create a fingerprint table.
    ///
    /// # Arguments
    ///
    /// - `num_buckets` — total number of buckets.
    /// - `bucket_size` — slots per bucket.
    /// - `fingerprint_bits` — fingerprint bit width.
    ///
    /// # Constraints
    ///
    /// - `fingerprint_bits` must be in `1..=64`.
    ///
    /// Constraints on these parameters are not enforced by this constructor, but must be upheld by callers to ensure correct filter behavior.
    ///
    /// # Returns
    ///
    /// A zero-initialised [`FingerprintTable`] with `⌈num_buckets·bucket_size·fingerprint_bits/8⌉ + 16` bytes allocated.
    ///
    /// # Examples
    ///
    /// ```rust,ignore
    /// use segmented_cuckoo::fingerprint_table::FingerprintTable;
    ///
    /// let mut table = FingerprintTable::new(64, 4, 12);
    /// assert_eq!(table.num_buckets(), 64);
    /// assert_eq!(table.bucket_size(), 4);
    /// assert_eq!(table.fingerprint_bits(), 12);
    /// ```
    pub fn new(num_buckets: u32, bucket_size: u32, fingerprint_bits: u32) -> Self {
        let total_bits = num_buckets as u64 * bucket_size as u64 * fingerprint_bits as u64;
        let total_bytes = total_bits.div_ceil(8) as usize;
        Self {
            data: vec![0u8; total_bytes + 16],
            num_buckets,
            bucket_size,
            fingerprint_bits,
        }
    }

    /// Total number of buckets.
    #[inline]
    pub const fn num_buckets(&self) -> u32 {
        self.num_buckets
    }

    /// Slots (fingerprints) per bucket.
    #[inline]
    pub const fn bucket_size(&self) -> u32 {
        self.bucket_size
    }

    /// Bit width of each fingerprint (1–64).
    #[inline]
    pub const fn fingerprint_bits(&self) -> u32 {
        self.fingerprint_bits
    }

    /// Return the byte size of the fingerprint storage, excluding the trailing 16-byte padding.
    ///
    /// This is the *logical* storage cost: `⌈num_buckets · bucket_size · fingerprint_bits / 8⌉`. Callers use this to
    /// report memory usage without counting implementation overhead.
    ///
    /// # Returns
    ///
    /// Byte count of fingerprint data, rounded up to the nearest byte.
    ///
    /// # Performance
    ///
    /// O(1) — arithmetic only.
    ///
    /// # Examples
    ///
    /// ```rust,ignore
    /// use segmented_cuckoo::fingerprint_table::FingerprintTable;
    ///
    /// // 64 buckets × 4 slots × 12 bits = 3072 bits = 384 bytes
    /// let table = FingerprintTable::new(64, 4, 12);
    /// assert_eq!(table.size_in_bytes(), 384);
    /// ```
    pub const fn size_in_bytes(&self) -> usize {
        let total_bits =
            self.num_buckets as u64 * self.bucket_size as u64 * self.fingerprint_bits as u64;
        total_bits.div_ceil(8) as usize
    }

    #[inline]
    const fn slot_index(&self, bucket: u32, slot: u32) -> usize {
        bucket as usize * self.bucket_size as usize + slot as usize
    }

    #[inline]
    const fn bit_offset(&self, bucket: u32, slot: u32) -> usize {
        self.slot_index(bucket, slot) * self.fingerprint_bits as usize
    }

    /// Read the fingerprint stored at `(bucket, slot)`.
    ///
    /// Loads a little-endian window (8-byte while `fingerprint_bits <= 56`, 16-byte above)
    /// from the byte boundary at or before the fingerprint's bit offset, then shifts and
    /// masks to extract exactly `fingerprint_bits` bits.
    ///
    /// # Arguments
    ///
    /// - `bucket` — bucket index.
    /// - `slot` — slot index within the bucket.
    ///
    /// # Constraints
    ///
    /// - `bucket` must be in `[0, num_buckets)`.
    /// - `slot` must be in `[0, bucket_size)`.
    ///
    /// # Returns
    ///
    /// The fingerprint value, zero-padded to `u64`. A return value of `0` means the slot
    /// is empty (the "empty = 0" invariant is enforced by [`insert`]).
    ///
    /// # Performance
    ///
    /// O(1) — one unaligned load (`u64` while `fingerprint_bits <= 56`, `u128` above),
    /// shift, mask. Past 56 bits a fingerprint can span up to 9 bytes at a non-zero
    /// intra-byte offset, which an 8-byte load cannot cover; see the width-split note in
    /// the type-level docs.
    ///
    /// # Panics
    ///
    /// Panics if `bucket >= num_buckets` or `slot >= bucket_size`.
    ///
    /// # Examples
    ///
    /// ```rust,ignore
    /// use segmented_cuckoo::fingerprint_table::FingerprintTable;
    ///
    /// let mut table = FingerprintTable::new(4, 2, 12);
    /// table.write(1, 0, 0xABC);
    /// assert_eq!(table.read(1, 0), 0xABC);
    /// assert_eq!(table.read(1, 1), 0); // slot still empty
    /// ```
    ///
    /// [`insert`]: Self::insert
    ///
    /// The `expect` is an invariant: the 16-byte padding allocation guarantees the slice is
    /// always exactly 16 bytes, so `try_into()` cannot fail.
    #[inline]
    #[allow(clippy::expect_used)]
    pub fn read(&self, bucket: u32, slot: u32) -> u64 {
        assert!(
            bucket < self.num_buckets && slot < self.bucket_size,
            "(bucket, slot) out of range: ({bucket}, {slot}) not in [0, {}) x [0, {})",
            self.num_buckets,
            self.bucket_size,
        );
        let bit_pos = self.bit_offset(bucket, slot);
        let byte_pos = bit_pos / 8;
        let bit_shift = bit_pos % 8;
        // Window split: `bit_shift` <= 7, so a `fingerprint_bits`-wide field spans at
        // most `7 + fingerprint_bits` bits of the load. Up to 56 bits that is <= 63,
        // and the original single 8-byte load still covers it — keeping the
        // Table 2 throughput benches (which hot-loop this path) at their
        // pre-widening cost. Only wider fingerprints pay the two-register
        // u128 window that a 9-byte span requires.
        if self.fingerprint_bits <= 56 {
            // fingerprint_bits <= 56 < 64, so the u64 mask shift cannot overflow.
            let mask = (1u64 << self.fingerprint_bits) - 1;
            // SAFETY-equivalent: the 16-byte padding at the end of `data` covers
            // this 8-byte load a fortiori.
            let val = u64::from_le_bytes(
                self.data[byte_pos..byte_pos + 8]
                    .try_into()
                    .expect("invariant: 8-byte slice always converts to [u8; 8]"),
            );
            (val >> bit_shift) & mask
        } else {
            // `fingerprint_bits` is at most 64, so this shift is always < 127.
            let mask = (1u128 << self.fingerprint_bits) - 1;
            // SAFETY-equivalent: the 16-byte padding at the end of `data` guarantees
            // that loading 16 bytes at `byte_pos` never exceeds the allocation.
            let val = u128::from_le_bytes(
                self.data[byte_pos..byte_pos + 16]
                    .try_into()
                    .expect("invariant: 16-byte slice always converts to [u8; 16]"),
            );
            ((val >> bit_shift) & mask) as u64
        }
    }

    /// Write `fingerprint` into the slot at `(bucket, slot)`.
    ///
    /// Performs a read-modify-write on the window that covers the fingerprint's bit
    /// range (8-byte while `fingerprint_bits <= 56`, 16-byte above): clears the existing
    /// `fingerprint_bits` bits, then OR-in the new value.
    ///
    /// # Arguments
    ///
    /// - `bucket` — bucket index.
    /// - `slot` — slot index within the bucket.
    /// - `fingerprint` — the fingerprint to write; only the lower `fingerprint_bits` bits are
    ///   stored. Pass `0` to mark the slot as empty.
    ///
    /// # Constraints
    ///
    /// - `bucket` must be in `[0, num_buckets)`.
    /// - `slot` must be in `[0, bucket_size)`.
    ///
    /// # Performance
    ///
    /// O(1) — one unaligned load, mask, OR, store (`u64` window while
    /// `fingerprint_bits <= 56`, `u128` above; see the type-level docs).
    ///
    /// # Panics
    ///
    /// Panics if `bucket >= num_buckets` or `slot >= bucket_size`.
    ///
    /// # Examples
    ///
    /// ```rust,ignore
    /// use segmented_cuckoo::fingerprint_table::FingerprintTable;
    ///
    /// let mut table = FingerprintTable::new(4, 4, 12);
    /// table.write(0, 3, 0xFFF);
    /// assert_eq!(table.read(0, 3), 0xFFF);
    ///
    /// // Overwrite with 0 to mark as empty.
    /// table.write(0, 3, 0);
    /// assert_eq!(table.read(0, 3), 0);
    /// ```
    ///
    /// See [`read`](Self::read) for the `expect` invariant rationale.
    #[inline]
    #[allow(clippy::expect_used)]
    pub fn write(&mut self, bucket: u32, slot: u32, fingerprint: u64) {
        assert!(
            bucket < self.num_buckets && slot < self.bucket_size,
            "(bucket, slot) out of range: ({bucket}, {slot}) not in [0, {}) x [0, {})",
            self.num_buckets,
            self.bucket_size,
        );
        let bit_pos = self.bit_offset(bucket, slot);
        let byte_pos = bit_pos / 8;
        let bit_shift = bit_pos % 8;
        // Same width split as `read`: 8-byte window up to 56 bits, u128 above.
        if self.fingerprint_bits <= 56 {
            let mask = (1u64 << self.fingerprint_bits) - 1;
            // SAFETY-equivalent: see read — 16-byte padding covers the 8-byte window.
            let mut val = u64::from_le_bytes(
                self.data[byte_pos..byte_pos + 8]
                    .try_into()
                    .expect("invariant: 8-byte slice always converts to [u8; 8]"),
            );
            val &= !(mask << bit_shift);
            val |= (fingerprint & mask) << bit_shift;
            self.data[byte_pos..byte_pos + 8].copy_from_slice(&val.to_le_bytes());
        } else {
            let mask = (1u128 << self.fingerprint_bits) - 1;
            // SAFETY-equivalent: see read — 16-byte padding prevents out-of-bounds.
            let mut val = u128::from_le_bytes(
                self.data[byte_pos..byte_pos + 16]
                    .try_into()
                    .expect("invariant: 16-byte slice always converts to [u8; 16]"),
            );
            val &= !(mask << bit_shift);
            val |= (fingerprint as u128 & mask) << bit_shift;
            self.data[byte_pos..byte_pos + 16].copy_from_slice(&val.to_le_bytes());
        }
    }

    /// Return `true` if `fingerprint` is present in any slot of `bucket`.
    ///
    /// Scans each slot in the bucket linearly and compares against `fingerprint`. Used by
    /// [`CuckooFilter::contain`] to check membership without needing the slot index.
    ///
    /// # Arguments
    ///
    /// - `bucket` — bucket index.
    /// - `fingerprint` — the fingerprint to search for (0 means empty).
    ///
    /// # Constraints
    ///
    /// - `bucket` must be in `[0, num_buckets)`.
    /// - `fingerprint` must be non-zero for normal lookups; `0` is deliberately allowed to
    ///   support finding empty slots.
    ///
    /// # Returns
    ///
    /// `true` if any slot in `bucket` holds `fingerprint`, `false` otherwise.
    ///
    /// # Performance
    ///
    /// O(bucket_size) — scans all `bucket_size` slots. In practice bucket_size ≤ 8, so this is a
    /// tight fixed-size loop.
    ///
    /// # Panics
    ///
    /// Panics if `bucket >= num_buckets` (already enforced in read).
    /// `fingerprint == 0` is deliberately allowed here to support finding empty slots.
    ///
    /// # Examples
    ///
    /// ```rust,ignore
    /// use segmented_cuckoo::fingerprint_table::FingerprintTable;
    ///
    /// let mut table = FingerprintTable::new(4, 4, 12);
    /// table.write(1, 2, 0x42);
    /// assert!(table.contain(1, 0x42));
    /// assert!(!table.contain(1, 0x99));
    /// ```
    ///
    /// [`CuckooFilter::contain`]: crate::CuckooFilter::contain
    pub fn contain(&self, bucket: u32, fingerprint: u64) -> bool {
        for slot in 0..self.bucket_size {
            if self.read(bucket, slot) == fingerprint {
                return true;
            }
        }
        false
    }

    /// Find the slot index of `fingerprint` within `bucket`.
    ///
    /// Like [`contain`] but also returns the matching slot index. Used
    /// internally during deletion when the matching slot must be zeroed.
    ///
    /// # Arguments
    ///
    /// - `bucket` — bucket index.
    /// - `fingerprint` — the fingerprint to find.
    ///
    /// # Constraints
    ///
    /// - `bucket` must be in `[0, num_buckets)`.
    ///
    /// # Returns
    ///
    /// `Some(slot)` if `fingerprint` is present, `None` otherwise.
    ///
    /// # Performance
    ///
    /// O(bucket_size) — linear scan over slots.
    ///
    /// # Panics
    ///
    /// Panics if `bucket >= num_buckets` (already enforced in read).
    /// `fingerprint == 0` is deliberately allowed here to support finding empty slots.
    ///
    /// # Examples
    ///
    /// ```rust,ignore
    /// use segmented_cuckoo::fingerprint_table::FingerprintTable;
    ///
    /// let mut table = FingerprintTable::new(4, 4, 12);
    /// table.write(0, 2, 0xFF);
    /// assert_eq!(table.find(0, 0xFF), Some(2));
    /// assert_eq!(table.find(0, 0xAB), None);
    /// ```
    ///
    /// [`contain`]: Self::contain
    #[allow(dead_code)]
    pub fn find(&self, bucket: u32, fingerprint: u64) -> Option<u32> {
        (0..self.bucket_size).find(|&slot| self.read(bucket, slot) == fingerprint)
    }

    /// Delete the first occurrence of `fingerprint` from `bucket` by writing `0` to that slot.
    ///
    /// Writing `0` marks the slot as empty, consistent with the "empty = 0" invariant.
    /// Only the first matching slot is cleared; duplicate fingerprints (from multiple
    /// insertions of the same item) are deleted one at a time.
    ///
    /// # Arguments
    ///
    /// - `bucket` — bucket index.
    /// - `fingerprint` — the fingerprint to remove.
    ///
    /// # Returns
    ///
    /// `true` if `fingerprint` was found and cleared, `false` if it was not in `bucket`.
    ///
    /// # Performance
    ///
    /// O(bucket_size) — linear scan; clears at most one slot.
    ///
    /// # Panics
    ///
    /// Panics if `bucket >= num_buckets` or if `fingerprint == 0` (0 is reserved for empty slots and cannot be a valid fingerprint).
    ///
    /// # Examples
    ///
    /// ```rust,ignore
    /// use segmented_cuckoo::fingerprint_table::FingerprintTable;
    ///
    /// let mut table = FingerprintTable::new(4, 4, 8);
    /// table.write(0, 0, 42);
    /// assert!(table.delete(0, 42));
    /// assert!(!table.contain(0, 42)); // gone
    /// assert!(!table.delete(0, 99)); // not present
    /// ```
    pub fn delete(&mut self, bucket: u32, fingerprint: u64) -> bool {
        assert!(fingerprint != 0, "fingerprint cannot be zero");
        for slot in 0..self.bucket_size {
            if self.read(bucket, slot) == fingerprint {
                self.write(bucket, slot, 0);
                return true;
            }
        }
        false
    }

    /// Insert `fingerprint` into the first empty (zero) slot of `bucket`.
    ///
    /// Scans for the first slot where `read == 0` and writes `fingerprint` there.
    /// Empty slots are identified by the value 0, which is why fingerprint 0 is forbidden for
    /// real items.
    ///
    /// # Arguments
    ///
    /// - `bucket` — bucket index.
    /// - `fingerprint` — the fingerprint to insert.
    ///
    /// # Constraints
    ///
    /// - `fingerprint` must be non-zero.
    ///
    /// # Returns
    ///
    /// `Some(slot)` with the slot index that was used, or `None` if all `bucket_size` slots in
    /// `bucket` are occupied.
    ///
    /// # Performance
    ///
    /// O(bucket_size) — linear scan; writes at most one slot.
    ///
    /// # Panics
    ///
    /// Panics if `bucket >= num_buckets` (already enforced in read)
    /// or if `fingerprint == 0` (0 is reserved for empty slots and cannot be a valid fingerprint).
    ///
    /// # Examples
    ///
    /// ```rust,ignore
    /// use segmented_cuckoo::fingerprint_table::FingerprintTable;
    ///
    /// let mut table = FingerprintTable::new(4, 2, 8);
    /// assert_eq!(table.insert(0, 10), Some(0));
    /// assert_eq!(table.insert(0, 20), Some(1));
    /// assert_eq!(table.insert(0, 30), None);  // bucket full (bucket_size=2)
    /// ```
    pub fn insert(&mut self, bucket: u32, fingerprint: u64) -> Option<u32> {
        assert!(fingerprint != 0, "fingerprint cannot be zero");
        for slot in 0..self.bucket_size {
            if self.read(bucket, slot) == 0 {
                self.write(bucket, slot, fingerprint);
                return Some(slot);
            }
        }
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_read_write_8bit() {
        let mut table = FingerprintTable::new(16, 4, 8);
        table.write(3, 2, 0xAB);
        assert_eq!(table.read(3, 2), 0xAB);
        assert_eq!(table.read(3, 1), 0);
    }

    #[test]
    fn test_read_write_12bit() {
        let mut table = FingerprintTable::new(16, 4, 12);
        table.write(5, 1, 0xFED);
        assert_eq!(table.read(5, 1), 0xFED);
        table.write(5, 2, 0x123);
        assert_eq!(table.read(5, 2), 0x123);
        assert_eq!(table.read(5, 1), 0xFED); // unchanged
    }

    #[test]
    fn test_read_write_16bit() {
        let mut table = FingerprintTable::new(8, 4, 16);
        table.write(7, 3, 0xBEEF);
        assert_eq!(table.read(7, 3), 0xBEEF);
    }

    #[test]
    fn test_read_write_32bit() {
        let mut table = FingerprintTable::new(4, 2, 32);
        table.write(1, 0, 0xDEADBEEF);
        assert_eq!(table.read(1, 0), 0xDEADBEEF);
    }

    #[test]
    fn test_read_write_64bit() {
        let mut table = FingerprintTable::new(4, 2, 64);
        table.write(1, 0, 0xDEAD_BEEF_1234_5678);
        assert_eq!(table.read(1, 0), 0xDEAD_BEEF_1234_5678);
        assert_eq!(table.read(1, 1), 0);
    }

    /// `fingerprint_bits = 64`, all-ones value: exercises the exact mask
    /// `u64::MAX`, computed as `(1u128 << 64) - 1` without ever needing the
    /// UB-adjacent `1u64 << 64`.
    #[test]
    fn test_read_write_64bit_all_ones() {
        let mut table = FingerprintTable::new(4, 2, 64);
        table.write(2, 1, u64::MAX);
        assert_eq!(table.read(2, 1), u64::MAX);
        assert_eq!(table.read(2, 0), 0);
    }

    /// `fingerprint_bits = 33` — one bit past the old 32-bit cap — at slots
    /// whose bit offsets (`slot_index * 33`) land at different, non-zero
    /// intra-byte positions (`slot_index * 33 mod 8` = 0, 1, 2, 3, 4 for
    /// slots 0..5). Exercises the general straddling path at a width the
    /// pre-widening code could never reach.
    #[test]
    fn test_read_write_33bit_odd_offsets() {
        let mut table = FingerprintTable::new(4, 5, 33);
        let values: [u64; 5] = [
            0x1_FFFF_FFFF, // 2^33 - 1: every one of the 33 bits set
            1,
            0x1_0000_0001,
            0x1_5555_5555,
            0x1_AAAA_AAAA,
        ];
        for (s, &v) in values.iter().enumerate() {
            table.write(0, s as u32, v);
        }
        for (s, &v) in values.iter().enumerate() {
            assert_eq!(table.read(0, s as u32), v, "slot {s}");
        }
    }

    /// Round-trips on both sides of the load-window split (`u64` while
    /// `fingerprint_bits <= 56`, `u128` above): 55 and 56 take the 8-byte
    /// window at its widest, 57 is the narrowest width on the `u128` path.
    /// Odd widths make successive slots land at different intra-byte
    /// offsets, so the straddling arithmetic is exercised on each path.
    #[test]
    fn test_read_write_across_window_split_boundary() {
        for fp_bits in [55u32, 56, 57] {
            let mut table = FingerprintTable::new(2, 6, fp_bits);
            // fp_bits <= 57 < 64 here, so the mask shift cannot overflow.
            let mask = (1u64 << fp_bits) - 1;
            let values: Vec<u64> = (0..6u64)
                .map(|s| (0xA5A5_5A5A_DEAD_BEEFu64.rotate_left(s as u32 * 11) | 1) & mask)
                .collect();
            for (s, &v) in values.iter().enumerate() {
                table.write(1, s as u32, v);
            }
            for (s, &v) in values.iter().enumerate() {
                assert_eq!(table.read(1, s as u32), v, "fp_bits={fp_bits} slot {s}");
            }
        }
    }

    #[test]
    fn test_find_and_delete() {
        let mut table = FingerprintTable::new(8, 4, 12);
        table.write(2, 0, 100);
        table.write(2, 1, 200);
        table.write(2, 2, 300);
        assert!(table.contain(2, 200));
        assert!(!table.contain(2, 999));
        assert!(table.delete(2, 200));
        assert!(!table.contain(2, 200));
    }

    #[test]
    fn test_insert_fingerprint() {
        let mut table = FingerprintTable::new(4, 2, 8);
        assert_eq!(table.insert(0, 10), Some(0));
        assert_eq!(table.insert(0, 20), Some(1));
        assert_eq!(table.insert(0, 30), None); // bucket full
        assert!(table.contain(0, 10));
        assert!(table.contain(0, 20));
    }

    #[test]
    fn test_find_fingerprint_in_bucket_slot() {
        let mut table = FingerprintTable::new(4, 4, 8);
        table.write(1, 0, 10);
        table.write(1, 2, 30);
        assert_eq!(table.find(1, 10), Some(0));
        assert_eq!(table.find(1, 30), Some(2));
        assert_eq!(table.find(1, 99), None);
    }

    #[test]
    fn test_delete_absent_fingerprint() {
        let mut table = FingerprintTable::new(4, 2, 8);
        assert!(!table.delete(0, 42));
    }

    #[test]
    fn test_size_in_bytes() {
        // 16 buckets * 4 slots * 12 bits = 768 bits = 96 bytes
        let table = FingerprintTable::new(16, 4, 12);
        assert_eq!(table.size_in_bytes(), 96);
        // 8 * 2 * 16 = 256 bits = 32 bytes
        let table2 = FingerprintTable::new(8, 2, 16);
        assert_eq!(table2.size_in_bytes(), 32);
    }

    // -------- Input-validation panic tests --------

    #[test]
    #[should_panic(expected = "out of range")]
    fn read_panics_on_bucket_oob() {
        let table = FingerprintTable::new(4, 2, 8);
        let _ = table.read(4, 0);
    }

    #[test]
    #[should_panic(expected = "out of range")]
    fn read_panics_on_slot_oob() {
        let table = FingerprintTable::new(4, 2, 8);
        let _ = table.read(0, 2);
    }

    #[test]
    #[should_panic(expected = "out of range")]
    fn read_panics_on_far_oob_bucket() {
        let table = FingerprintTable::new(4, 2, 8);
        let _ = table.read(u32::MAX, 0);
    }

    #[test]
    #[should_panic(expected = "out of range")]
    fn write_panics_on_bucket_oob() {
        let mut table = FingerprintTable::new(4, 2, 8);
        table.write(4, 0, 1);
    }

    #[test]
    #[should_panic(expected = "out of range")]
    fn write_panics_on_slot_oob() {
        let mut table = FingerprintTable::new(4, 2, 8);
        table.write(0, 2, 1);
    }

    #[test]
    #[should_panic(expected = "out of range")]
    fn contain_panics_on_bucket_oob() {
        let table = FingerprintTable::new(4, 2, 8);
        let _ = table.contain(4, 1);
    }

    #[test]
    #[should_panic(expected = "out of range")]
    fn find_panics_on_bucket_oob() {
        let table = FingerprintTable::new(4, 2, 8);
        let _ = table.find(4, 1);
    }

    #[test]
    #[should_panic(expected = "fingerprint cannot be zero")]
    fn delete_panics_on_zero_fingerprint() {
        let mut table = FingerprintTable::new(4, 2, 8);
        let _ = table.delete(0, 0);
    }

    #[test]
    #[should_panic(expected = "out of range")]
    fn delete_panics_on_bucket_oob() {
        let mut table = FingerprintTable::new(4, 2, 8);
        let _ = table.delete(4, 1);
    }

    #[test]
    #[should_panic(expected = "fingerprint cannot be zero")]
    fn insert_panics_on_zero_fingerprint() {
        let mut table = FingerprintTable::new(4, 2, 8);
        let _ = table.insert(0, 0);
    }

    #[test]
    #[should_panic(expected = "out of range")]
    fn insert_panics_on_bucket_oob() {
        let mut table = FingerprintTable::new(4, 2, 8);
        let _ = table.insert(4, 1);
    }
}
