# CLAUDE.md — ikpir-common crate

## 1. Crate purpose

Shared building blocks of the IKPIR protocol that both server and client
consume but neither owns: the **pluggable Index-PIR backend trait
family**, the two shipped **LWE backends (FrodoPIR and SimplePIR)**, the
**wire-format bundles** exchanged across the server/client boundary, and
the shared **`IkpirError`** enum.

`ikpir-server` and `ikpir-client` both depend on this crate and re-export
the items they expose in their own public signatures, so existing call
sites (`use ikpir_server::IndexPirBackend`, `use ikpir_client::FrodoConfig`,
`use ikpir_server::ServerSetupBundle`, ...) keep resolving unchanged.

## 2. File map

| File | Role |
|---|---|
| `src/lib.rs` | Top-level re-exports of `backend`, `wire`, and `error` |
| `src/error.rs` | `IkpirError` enum (5 variants) — returned by server methods, wrapped by `IkpirClientError::Server` on the client side |
| `src/wire.rs` | Wire-format bundles `ServerSetupBundle / PirQueryBundle / PirResponseBundle / HintDeltaBundle`, the `SegmentRowDeltas` type alias, per-bundle `wire_byte_size` helpers, and `HintDeltaBundle`'s specified bit-packed encoding (`DeltaWireLayout`, `DeltaWireStats`, `WireError`, `encode` / `decode` — `docs/hint-delta-wire-format.md`) |
| `src/backend/mod.rs` | Trait family: `IndexPirBackend` (6 associated types incl. `Config` + 7 methods), `IncrementalPirBackend` (+2 methods, both taking a `HintPatchMode`), `PrecomputingPirBackend` (+4 methods), `BackendWireSize` (+4 methods), `ResponseRewind` (+1 method, the client-rewind flow's correction — impl'd in `backend/{frodo,simple}/backend.rs` — `docs/rewind-client-mode.md`); `HintPatchMode` enum (`RowLevel` / `EntryLevel`, default `EntryLevel` — the realization of a hint patch, used by the server's live hint and by the client-hint-patch flow, `HintPatchClient`) |
| `src/backend/frodo/mod.rs` | Re-exports the FrodoPIR backend's public surface |
| `src/backend/frodo/params.rs` | `FrodoParams` (per-segment runtime values) + `FrodoConfig` (user-facing tunable knobs, default `lwe_dim = 1566`) |
| `src/backend/frodo/backend.rs` | `FrodoPirBackend` impl of all four traits + `FrodoServerParams / FrodoHint / FrodoClientState / FrodoQuery / FrodoResponse` |
| `src/backend/matvec.rs` | `matvec_accumulate` — shared width-adaptive register-blocked `acc += qᵀ·D` kernel used by every online hot loop (`server_answer`, `client_decode` cold path, `compute_c`) in both backends; bit-exact vs the naive loop, no explicit SIMD/threads |
| `src/backend/patch.rs` | `TouchedRuns` — the entry-level hint patch's inner loop, shared by both backends: coalesces one row's touched hint columns into contiguous runs, then applies `H[k, c] += A[row, k] · Δ_c` with `k` outermost, sweeping the hint once instead of once per touched column |
| `src/backend/parallel.rs` | `setup_threads` / `balanced_chunk_len` / `par_chunks_mut` — `std::thread::scope` fan-out behind the optimized setup path; no dependency, static disjoint-output partition, worker count via `IKPIR_SETUP_THREADS` (clamped to `MAX_SETUP_THREADS`). Also the single source of truth for the fan-out thresholds `PAR_MIN_HINT_MACS` / `PAR_MIN_WORDS`, which both backends and their tests read |
| `src/backend/frodo/arith.rs` | `round_p_to_q` / `round_q_to_p` — plaintext ↔ ciphertext modulus conversion |
| `src/backend/frodo/sampler.rs` | `sample_a` (LWE public matrix) + `sample_ternary_into` (LWE secret / error sampling) |
| `src/backend/simple/mod.rs` | Re-exports the SimplePIR backend's public surface + math summary |
| `src/backend/simple/params.rs` | `SimpleParams` + `SimpleConfig` (user-facing knobs, default `lwe_dim = 1275`, `sigma = 6.4`) |
| `src/backend/simple/backend.rs` | `SimplePirBackend` impl of all four traits + `SimpleServerParams / SimpleHint / SimpleClientState / SimpleQuery / SimpleResponse` + internal `reshape_dims` / `translate` helpers |
| `src/backend/simple/arith.rs` | Δ-scaling (duplicated from frodo per project rule) |
| `src/backend/simple/sampler.rs` | `sample_a` + `sample_uniform_zq_into` (secret) + `sample_discrete_gaussian_into` (true discrete Gaussian `D_σ`, table rejection sampler after `ahenzinger/simplepir pir/gauss.go`) |
| `src/pir_params.rs` | Operating-point selection: `frodo_max_plaintext_bits` / `simple_max_plaintext_bits` — the largest `plaintext_bits` each backend decodes correctly at `q = 2³²`, evaluated at the per-segment matrix shape (full derivation of both correctness bounds in the module docs) |
| `examples/max_plaintext_bits.rs` | Dependency-free CLI over `pir_params`, consumed by `scripts/lib.sh::backend_plaintext_bits` (sourced by `scripts/bench.sh`) |

## 3. Key design decisions (the WHY)

- **Sibling-crate placement** — backend traits, FrodoPIR, wire bundles,
  and the shared error live here rather than in `ikpir-server` so that
  `ikpir-client` is no longer a downstream consumer of the server crate.
  The two protocol crates now consume `ikpir-common` as siblings;
  `ikpir-client` depends on `ikpir-server` only via `[dev-dependencies]`
  for end-to-end tests, benches, and the doctest in its quick-start.

- **Re-export discipline** — `ikpir-server` and `ikpir-client` both
  re-export the common items they expose in their own signatures
  (`IndexPirBackend`, `FrodoConfig`, all four bundle types, `IkpirError`).
  Every shared item resolves under all three crate paths; callers pick
  whichever is most ergonomic for their import context.

- **Three-layer trait hierarchy** — `IndexPirBackend` is mandatory and
  defines the basic `setup/query/answer/decode` triple. `IncrementalPirBackend`
  is optional and adds `server_patch_hint / client_patch_state` for
  full-rebuild-free DB mutations. `PrecomputingPirBackend` is optional
  and adds Phase B / Phase C precomputation for amortising per-query
  LWE work (FrodoPIR Fig. 1). `ParallelSetupBackend` is optional and
  adds a multi-threaded realization of the three setup entry points.
  `BackendWireSize` is optional and reports per-type byte sizes for
  wire-size benches. A backend that doesn't implement an optional
  extension is simply unavailable on the corresponding code path.

- **Two setup implementations, one result** — setup is
  `Θ(n_rows · lwe_dim · row_width)`, minutes to hours at paper scale,
  and it is the price of *reaching* the state most benchmarks want to
  measure rather than anything they measure. So the base trait's
  `server_setup` / `expand_hint_material` / `client_setup` stay
  single-threaded and non-SIMD — the regime the paper reports and
  `benches/server_setup.rs` times — and `ParallelSetupBackend` supplies
  `server_setup_parallel` / `expand_hint_material_parallel` /
  `client_setup_parallel` alongside them. Both shipped backends
  implement it; measured speedup on 8 cores is 4.8× (FrodoPIR) and
  6.3× (SimplePIR).

  The optimized path is **bit-identical, not merely equivalent**, and
  by construction rather than by argument: it partitions only the
  *output* — disjoint bands of `H` rows, disjoint runs of the ChaCha20
  keystream (`set_word_pos`) — so each output cell still accumulates
  the same terms in the same order. That is what lets a server built
  on one path interoperate with a client built on the other, which
  `ikpir-server/tests/parallel_setup_equivalence.rs` pins for every
  combination. Threading is `std::thread::scope`: the partition is
  already balanced, so a work-stealing runtime would buy nothing and
  cost a dependency in a crypto crate.

  The schedule depends only on public shape and the core count, never
  on cell values, so the parallel path inherits the base trait's
  side-channel posture.

- **Two hint-patch realizations, one wire format** — both
  `IncrementalPirBackend` methods take a `HintPatchMode` selecting the
  realization of the patch: `RowLevel` (the SimplePIR row-granular
  patch — densify each touched row's edits and apply a dense rank-one
  update, `Θ(n·ω)` per touched row) or `EntryLevel` (the iSimplePIR
  sharpening — patch only touched columns, `Θ(n)` per touched cell;
  the default). Either mode leaves the hint equal to `A·D mod 2³²` and
  consumes the same `HintDeltaBundle`, so the mode is a purely local
  compute choice: server and client may run different modes and never
  diverge. The mutation benches sweep both to isolate the granularity
  cost — the two mutation-phase columns of the paper's asymptotic
  table. `patch_slot_c` (Phase-C maintenance) is deliberately
  mode-independent: it is inherently sparse and identical either way.

  **Execution order is what makes the entry-level cost real.** `H` is
  row-major, so the literal reading of `H[k, c] += A[row, k] · Δ_c` —
  one touched column at a time, `k` inside — strides `hint_row_width`
  per step and drags `lwe_dim` distinct cache lines through the machine
  *per touched column*: `t` columns, `t` full passes over a
  multi-megabyte hint. Written that way the mode lost in wall-clock to
  the dense row-level pass it beats on paper (measured: 1.4–4× slower).
  `backend/patch.rs::TouchedRuns` inverts it — `k` outermost, touched
  columns coalesced into contiguous runs inside — so the patch sweeps
  the hint once with the same slice-shaped kernel the row-level pass
  uses, restricted to the touched part of each row. Same arithmetic,
  same bits; entry-level now runs 2.3–3.3× *faster* than row-level at
  the dev geometry, in the direction the asymptotics predict. A slot's
  cells are contiguous by construction (`cell_offset = slot ·
  cells_per_slot + c`, and SimplePIR's reshape translation is affine in
  the offset), which is what makes the runs long enough to matter.

- **No I/O, no serialisation in three of the four wire types** —
  `ServerSetupBundle`, `PirQueryBundle`, and `PirResponseBundle` are
  plain data crossing process boundaries by value within tests and
  examples. Production deployments layer their own serialiser on top;
  their `wire_byte_size()` reports the *minimum* on-wire footprint under
  fixed-width little-endian encoding so configs can be compared without
  committing to a specific format. **`HintDeltaBundle` is the exception**:
  it has a normative, bit-packed on-wire encoding
  (`docs/hint-delta-wire-format.md`, `wire.rs::{encode, decode}`), and its
  `wire_byte_size()` equals `encode().len()` exactly, by construction and
  by test — not a minimum-footprint estimate.

- **`HintDeltaBundle::new` is `#[doc(hidden)] pub`** — the constructor
  must be reachable from `ikpir-server` (sibling crate) but is hidden
  from the public API. It takes `(epoch, per_segment_row_deltas, params)`
  and skips the invariant checks that `RewindClient::accumulate_delta` then
  trusts (epoch monotonicity, `delta.params == self.params`,
  `per_segment_row_deltas.len() == arity`); only
  `IkpirServer::commit_mutations` is permitted to call it, passing its
  own `self.params` — the geometry the deltas were folded under, never
  itself on the wire (`docs/hint-delta-wire-format.md` §2).

- **`SegmentRowDeltas` is `pub`** (was `pub(crate)` before the split) —
  the type appears in the public `HintDeltaBundle` field, and
  `ikpir-server::hint_patch::fold_mutations_into_row_deltas` (now in a
  sibling crate) must produce values of this type.

- **Threat model unchanged** — Index-PIR hides the queried row within
  each segment. The SCF candidate-bucket set is public and
  deterministic; an observer who sees many queries learns which SCF
  buckets were touched, not the slot contents or fingerprint value.
  On side channels: the LWE matvecs avoid data-dependent shortcuts on
  secret values (skips keyed only on the public matrix `A` are fine),
  and `RewindClient::decode` scans fingerprints with a branchless
  compare as best-effort hardening — but a full constant-time-audited
  decode path is out of scope for this prototype.

## 4. Trait family

```text
IndexPirBackend (mandatory)
│   ServerParams / HintMaterial / Hint / ClientState / Query / Response / Config
│   server_setup(config, db, n_rows, row_width, plaintext_bits)
│       -> (ServerParams, HintMaterial, Hint)
│   db_matrix_shape(params) -> (rows, cols)
│   expand_hint_material(params) -> HintMaterial
│   client_setup(params, hint) -> ClientState
│   client_query(state, row) -> Query
│   server_answer(params, db, n_rows, row_width, query) -> Response
│   client_decode(state, response) -> Vec<u32>
│
├── IncrementalPirBackend
│   server_patch_hint(params, material, hint, row_deltas, mode)
│   client_patch_state(state, row_deltas, mode)
│       mode: HintPatchMode = RowLevel | EntryLevel (default EntryLevel)
│
├── PrecomputingPirBackend
│   client_precompute_queries(state, count)        — Phase B
│   client_precompute_decodes(state)               — Phase C
│   prepared_slot_count(state) -> usize
│   in_flight_slot_count(state) -> usize
│
├── ParallelSetupBackend        — same results, across cores
│   server_setup_parallel(config, db, n_rows, row_width, plaintext_bits)
│   expand_hint_material_parallel(params) -> HintMaterial
│   client_setup_parallel(params, hint) -> ClientState
│
├── BackendWireSize
│   query_byte_size(q) / response_byte_size(r) / hint_byte_size(h) / server_params_byte_size(p)
│
└── ResponseRewind        — the client's rewind update mode (docs/rewind-client-mode.md)
    rewind_response(state, query, resp, deltas)   — resp -= qᵀ·ΔD for one segment,
        query is the marker-bearing vector the server answered; reads only public
        fields, so both shipped backends impl it in backend/{frodo,simple}/backend.rs
```

`HintMaterial` is server-local working state (e.g. the LWE public matrix
`A` expanded from a 16-byte seed inside `ServerParams`). It is **not**
shipped on the wire. `IkpirServer` holds a `Vec<Option<B::HintMaterial>>`
per segment and can free it via
[`drop_hint_material`](../ikpir-server/CLAUDE.md#section-3); the next
mutation transparently re-expands the affected segments via
`expand_hint_material`. The client always re-expands its own copy from
the seed during `client_setup` (the bundle does not carry `A`). The
determinism contract on `expand_hint_material` is load-bearing — the
server and client both rely on the same seed reproducing the same `A`
bit-for-bit.

`expand_hint_material_parallel` sits under the *same* determinism
contract, and across the two methods: whichever path expanded `A` last,
the bytes are the same, so server and client may pick independently.

Both `FrodoPirBackend` and `SimplePirBackend` implement all five traits.
They are drop-in alternatives at the `B: IndexPirBackend` type parameter
on `IkpirServer<S, B>` / `RewindClient<B>` / `HintPatchClient<B>`. The per-bench `--backend
frodo|simple` flag (default `frodo`) selects between them at runtime;
the `B::Config` associated type (`FrodoConfig` vs `SimpleConfig`)
carries the backend-specific tunables (`lwe_dim`, plus `sigma` for
SimplePIR).

## 5. Wire bundle taxonomy

| Bundle | Direction | Carries |
|---|---|---|
| `ServerSetupBundle<B>` | server → client | preprocessing material (`Hint`, `ServerParams`, `CuckooParams`, epoch). **Not** `HintMaterial` — the client re-expands `A` from the seed inside `ServerParams` via `expand_hint_material`. |
| `PirQueryBundle<B>` | client → server | one `B::Query` per segment + epoch |
| `PirResponseBundle<B>` | server → client | one `B::Response` per segment + epoch |
| `HintDeltaBundle<B>` | server → client | sparse per-segment row deltas + epoch + `CuckooParams` (after one mutation). The only bundle with a specified on-wire byte encoding. |

The exclusion of `HintMaterial` from `ServerSetupBundle` is what makes
the bundle small at paper scale. `setup_bundle_bytes` in the bench
preambles drops by ~`num_buckets × lwe_dim × 4` bytes (one full `A` per
setup) after this refactor.

`SegmentRowDeltas = Vec<(u32, Vec<(u16, i64)>)>` — per-segment list of
`(row_in_segment, [(cell_offset, signed_delta), …])`. Backend-agnostic:
contents are plain integers, no backend ciphertext. This is
`HintDeltaBundle`'s in-memory shape; its on-wire shape is the
run-length, bit-packed encoding in `docs/hint-delta-wire-format.md`
(`wire.rs::{encode, decode, wire_stats}` / `DeltaWireLayout` /
`WireError`), which `wire_byte_size()` reports exactly.

## 6. Failure-mode table (`IkpirError`)

| Variant | Source (server method) | Meaning |
|---|---|---|
| `StaleEpoch` | `answer` | client query against an older server epoch |
| `MalformedQuery` | `answer` | wrong number of segments in `q.queries` |
| `TableFull` | `insert` | SCF cuckoo kicks exhausted |
| `NotFound` | `update` / `delete` | key absent |
| `InvalidInput` | `insert` / `update` | bad value width |

`ikpir-client` re-exports `IkpirError` and wraps it in
`IkpirClientError::Server(IkpirError)` for synchronous in-process
composition.

## 7. Entry points

| Task | Where to look |
|---|---|
| Backend trait contract | `backend/mod.rs::IndexPirBackend` + the four extension traits |
| Max safe `plaintext_bits` for a geometry | `pir_params.rs` (library) / `examples/max_plaintext_bits.rs` (CLI); empirical validation via the `#[ignore]`d `noise_margin` tests in both `backend/*/backend.rs` |
| FrodoPIR config knobs | `backend/frodo/params.rs::FrodoConfig` (`lwe_dim`) |
| SimplePIR config knobs | `backend/simple/params.rs::SimpleConfig` (`lwe_dim`, `sigma`) |
| Implement a new backend | mirror `backend/frodo/backend.rs` (tall-skinny) or `backend/simple/backend.rs` (square reshape); see backend-author checklist below |
| Wire-bundle layout | `wire.rs` module docs + each bundle's labelled-section block |
| `HintDeltaBundle`'s on-wire byte encoding | `docs/hint-delta-wire-format.md` (normative spec) → `wire.rs::{DeltaWireLayout, DeltaWireStats, WireError, HintDeltaBundle::{encode, decode, wire_stats}}` |
| Shared error variants | `error.rs::IkpirError` |
| Round-trip cell-modulus conversion | `backend/frodo/arith.rs` (also duplicated in `backend/simple/arith.rs`) |
| Online matvec hot loop (`acc += qᵀ·D`) | `backend/matvec.rs::matvec_accumulate` — shared by both backends (unlike `arith.rs`, deliberately *not* duplicated: it is backend-agnostic linear algebra whose blocking tunables must never diverge) |
| Entry-level patch inner loop | `backend/patch.rs::TouchedRuns` — shared for the same reason as `matvec.rs`; the backends differ only in the `column_of` closure they pass (identity for FrodoPIR, the reshape translation for SimplePIR) |
| Optimized (multi-threaded) setup | `backend/mod.rs::ParallelSetupBackend` (contract) → `compute_hint_parallel` in each `backend/*/backend.rs` + `sample_a_parallel` in each `backend/*/sampler.rs`; fan-out in `backend/parallel.rs` |
| Worker count for the optimized setup | `backend/parallel.rs::setup_threads` — `IKPIR_SETUP_THREADS`, else `available_parallelism()`, clamped to `MAX_SETUP_THREADS` (1024) so a typo cannot spawn a thread per keystream buffer; set to `1` to force the reference schedule when bisecting |
| LWE sampling (FrodoPIR) | `backend/frodo/sampler.rs` (`sample_a`, `sample_a_parallel`, `sample_ternary_into`) |
| LWE sampling (SimplePIR) | `backend/simple/sampler.rs` (`sample_a`, `sample_a_parallel`, `sample_uniform_zq_into`, `sample_discrete_gaussian_into`) |
| Cross-crate integration tests | `ikpir-server/tests/frodo_compose.rs` + `simple_compose.rs` exercise each backend end-to-end against `IkpirServer` |

**Backend-author checklist** — a new `IndexPirBackend` impl must:

1. Define `Config: Clone + Default` holding the backend's tunable knobs
   (e.g. `FrodoConfig { lwe_dim }`, `SimpleConfig { lwe_dim, sigma }`).
2. Define `HintMaterial: Default + Send + 'static` for server-local
   working state (e.g. the LWE matrix `A`). Backends with no analogous
   material set `type HintMaterial = ()`. Don't derive `Clone` on a
   bulky `HintMaterial` — every "extra" copy should be an explicit
   `expand_hint_material` call.
3. `server_setup(config, db, n_rows, row_width, plaintext_bits)` returns
   `(ServerParams, HintMaterial, Hint)` from the DB slice and the
   supplied config.
4. `db_matrix_shape(params)` reports the `(rows, cols)` of the matrix the
   backend actually multiplies, **read back from `params`** — never
   recomputed from the caller's `(n_rows, row_width)`. A backend that
   reshapes (SimplePIR's near-square fold) must have stored its chosen
   dims in `ServerParams` at `server_setup` time and return those. This
   is what the benches' `db_rows` / `db_cols` columns report, so a
   re-derivation here would let the published geometry drift from the
   real one.
5. `expand_hint_material(params)` re-derives the `HintMaterial` from
   `ServerParams`. **Determinism contract**: same seed/state inside
   `params` must yield bit-identical output, since the server may drop
   and re-expand mid-protocol and the client materialises its own copy
   independently from the wire seed.
6. `client_setup` returns `ClientState` from `(ServerParams, Hint)`,
   internally calling `expand_hint_material(params)` and stashing both
   `params` and the materialised state.
7. The triple `(client_query, server_answer, client_decode)` must satisfy:
   `client_decode(server_answer(client_query(state, row))) == db[row*row_width..(row+1)*row_width]`.
8. If implementing `IncrementalPirBackend`: `server_patch_hint(params,
   material, hint, row_deltas, mode)` and `client_patch_state(state,
   row_deltas, mode)` must keep `Hint` and `ClientState` consistent with
   the updated DB for **all** future queries. `client_patch_state` reads
   `HintMaterial` from the stashed `ClientState`. Every `HintPatchMode`
   must produce the same post-patch state — the mode may only change the
   arithmetic schedule (row-level dense pass vs entry-level per-cell
   pass), never the result.
9. If implementing `PrecomputingPirBackend`: prepared slots are consumed
   FIFO segment-locally; `client_patch_state` must also update
   already-prepared Phase-C material (see the trait's contract block).
10. If implementing `BackendWireSize`: return the *minimum* fixed-width
   little-endian byte size — no framing, no compression. **Do not
   include `HintMaterial`** in `server_params_byte_size`; it never
   travels on the wire.
11. If implementing `ParallelSetupBackend`: the three `*_parallel`
   methods must return what their reference twins would have returned
   for the same seed — **bit-identical**, not just decode-equivalent.
   Get that by partitioning the *output* only (disjoint hint bands,
   disjoint keystream runs via `set_word_pos`) so accumulation order is
   unchanged; never by a reduction tree. Keep the schedule a function of
   public shape alone. Reuse `backend/parallel.rs` rather than spawning
   threads directly, and keep a sequential fallback below a size
   threshold so tiny unit-test shapes don't pay for thread spawn.
