# Incremental Keyword PIR (RisePIR)

A research prototype of **Incremental Keyword PIR (IKPIR)** — a single-server
keyword-PIR construction that supports efficient **insert / update / delete** on
the server's database, while preserving the one-round structure of
state-of-the-art schemes.

This is the open-source implementation accompanying the paper *"Incremental
Keyword Private Information Retrieval from d-ary Segmented Cuckoo Filters"*
(CANS 2026 submission). The paper builds IKPIR generically from any **updatable
index PIR (UIPIR)** and instantiates the construction over LWE as **RisePIR**,
in two variants:

- **RisePIR-F** — over FrodoPIR: `IkpirServer<S, FrodoPirBackend>` paired with a client at the same
  `B` — `RewindClient<FrodoPirBackend>` (client-rewind) or `HintPatchClient<FrodoPirBackend>`
  (client-hint-patch); `IkpirClient<FrodoPirBackend>` remains as a source-compatible alias of
  `RewindClient<FrodoPirBackend>`;
- **RisePIR-S** — over SimplePIR: `IkpirServer<S, SimplePirBackend>` paired the same way with
  `RewindClient<SimplePirBackend>` / `HintPatchClient<SimplePirBackend>`.

The crates keep the generic names (`ikpir-*`): the code implements the generic
IKPIR-from-UIPIR construction, and the RisePIR variants are what you get by
choosing a backend at the `B: IndexPirBackend` type parameter.

> **Status.** Research prototype. Interfaces, parameters, and internals are
> subject to change.
>
> **Reproducing a paper's numbers:** [`REPRODUCIBILITY.md`](REPRODUCIBILITY.md)
> maps each paper to its client flow, the exact command per table, and the
> output file — the camera-ready to client-hint-patch, the extended version to
> client-rewind.

## Background

Following the framework popularised by *ChalametPIR*, a keyword-PIR scheme can
be built from any **fingerprint-based filter** in two stages:

1. **Fingerprint filter → key-value store.**
   A fingerprint-based filter (e.g. Binary Fuse Filter, Cuckoo Filter) stores,
   for each inserted key `k`, a short fingerprint `fp(k)` placed at filter
   positions determined by a public, key-derived rule. The filter is upgraded
   into a key-value store by replacing each stored fingerprint with the pair
   `fp(k) ‖ v`. On lookup, the client reconstructs `fp(k) ‖ v` from the
   filter slots dictated by the public rule, checks the fingerprint, and — on
   match — accepts `v` as the value.

2. **Key-value store → keyword PIR.**
   The server publishes the key-value store as an array; the client knows,
   from the public rule, exactly which array indices it must read to recover
   `fp(k) ‖ v`. Reading those indices privately is the job of a standard
   **single-server Index-based PIR**. Because the rule selects a small,
   fixed-size set of indices, a single Index-PIR query suffices.

Under this framework, the choice of fingerprint-based filter determines the
*functionality* of the resulting keyword PIR.

## Why incremental?

ChalametPIR instantiates the framework with a **Binary Fuse Filter (BFF)**,
which is *static*: the entire filter must be rebuilt to insert, update, or
delete a key. For real-world databases — which evolve continuously — this
makes the static instantiation impractical.

A natural alternative is the standard **Cuckoo Filter**, which is dynamic.
However, Cuckoo Filter lookups read a *variable* number of buckets (usually
two, but the client cannot tell in advance which one holds the key). Plugged
into the framework above, this forces the client to issue **multiple
Index-PIR queries**, eroding the round and bandwidth profile that makes the
ChalametPIR-style construction attractive in the first place.

## This repository

This repository introduces the **Segmented Cuckoo Filter (SCF)** — a Cuckoo
Filter variant designed specifically for use as the fingerprint-based filter
inside the keyword-PIR framework. SCF is engineered so that:

- it supports **incremental** `insert`, `update`, and `delete`, like a
  standard Cuckoo Filter, and
- a key lookup reads a **deterministic, fixed set of slots**, so the resulting
  keyword PIR retains the **single Index-PIR query** profile of the static
  BFF-based construction.

Combined with an efficient preprocessing-update technique, SCF yields an
**Incremental Keyword PIR** scheme suitable for evolving databases.

## Compatibility

The construction is compatible with **any single-server Index-based PIR**
that supports efficient in-place updates — the paper's **UIPIR** interface,
realised in code as the `IndexPirBackend` (+ `IncrementalPirBackend`) trait
family. This repository ships two such backends, **FrodoPIR** and
**SimplePIR** — LWE-based Index-PIR schemes that offer high server throughput
and well-studied post-quantum security — yielding the paper's RisePIR-F and
RisePIR-S.

## Implementation status

| Component | Status |
|---|---|
| Segmented Cuckoo Filter + KV store | Shipped (`segmented-cuckoo`) |
| Backend trait family + wire bundles + shared error | Shipped (`ikpir-common`) |
| Server protocol (setup / answer / insert / update / delete / full_rebuild) | Shipped (`ikpir-server`) |
| Client, client-hint-patch (`HintPatchClient`: from_setup / build_query / decode / apply_delta / reset_from, selectable `HintPatchMode`) | Shipped (`ikpir-client`) |
| Client, client-rewind (`RewindClient`, alias `IkpirClient`: from_setup / build_query / decode / accumulate_delta / collect_garbage / reset_from) | Shipped (`ikpir-client`) |
| FrodoPIR backend | Shipped (`ikpir-common`) — ternary errors, tall-skinny matrix, default `lwe_dim = 1566` |
| SimplePIR backend | Shipped (`ikpir-common`) — discrete-Gaussian errors (σ = 6.4), √N×√N reshape, default `lwe_dim = 1275` |
| Hint-patch realizations (`HintPatchMode`) | Shipped (`ikpir-common`) — entry-level (iSimplePIR, default) and row-level (SimplePIR baseline); server-side, identical state + wire bytes either way |

## Repository tour

| Resource | Purpose |
|---|---|
| [`crates/segmented-cuckoo/CLAUDE.md`](crates/segmented-cuckoo/CLAUDE.md) | Filter + KV store internals, file map, design decisions |
| [`crates/ikpir-common/CLAUDE.md`](crates/ikpir-common/CLAUDE.md) | Shared crate internals: backend trait family, FrodoPIR, wire bundles, `IkpirError` |
| [`crates/ikpir-common/README.md`](crates/ikpir-common/README.md) | Shared crate role in the workspace + backend-author quick reference |
| [`crates/ikpir-server/CLAUDE.md`](crates/ikpir-server/CLAUDE.md) | Server crate internals, per-segment architecture, backend-author checklist |
| [`crates/ikpir-server/README.md`](crates/ikpir-server/README.md) | Server quick start and backend implementation guide |
| [`crates/ikpir-client/CLAUDE.md`](crates/ikpir-client/CLAUDE.md) | Client crate internals, epoch state machine, failure modes |
| [`crates/ikpir-client/README.md`](crates/ikpir-client/README.md) | Client quick start and lifecycle overview |
| [`CONTRIBUTING.md`](CONTRIBUTING.md) | Toolchain pin, local CI gates, bench workflow, PR conventions |
| [`SECURITY.md`](SECURITY.md) | Prototype threat-model caveats and private vulnerability reporting |

## Paper ↔ code notation

The paper's notation maps onto the code as follows.

**Filter layer (SCF / KV-SCF, paper §4–§5.1).**

| Paper | Meaning | Code |
|---|---|---|
| `d` | arity: candidate buckets per key = number of segments | `arity`, `CuckooParams::arity()` |
| `b` | slots per bucket | `bucket_size` |
| `n_b` | total buckets | `num_buckets` |
| `s = n_b / d` | buckets per segment (a power of two) | `CuckooParams::segment_size()` |
| `f` | fingerprint bits (benches fix 64) | `fingerprint_bits` |
| `ℓ` | value bits | `value_bits` |
| `fp(k) ‖ v` slot payload | fingerprint-then-value cell packing | `pack_slot_cells` / `unpack_slot_cells` |
| `MaxKicks` | eviction-walk budget | `MAX_KICKS_DEFAULT` (= 500) |
| `Candidates(x)` | candidate buckets of a key | `CuckooParams::candidate_buckets()`, `IndexScheme::hash_item` |
| `AltBuckets(i, φ)` | rebuild candidates from one bucket + fingerprint | `IndexScheme::all_indices` |
| write log `W` | per-mutation slot-change records | `SlotMutation`, `CuckooKVStore::drain_mutations` |
| `KV-SCF` | SCF-backed key-value store | `CuckooKVStore<S>` (`Segmented{2,3,4}aryCuckooKVStore`) |

**PIR layer (UIPIR / LWE-PIR, paper §3.1 and Appendix A).**

| Paper | Meaning | Code |
|---|---|---|
| `UIPIR.Setup` | preprocess one segment | `IndexPirBackend::server_setup` |
| `UIPIR.Query / Answer / Recover` | online phase | `client_query` / `server_answer` / `client_decode` |
| `UIPIR.DBMutation + HintUpdate` | mutation phase | server `insert/update/delete` → `IncrementalPirBackend::server_patch_hint`; client's `HintUpdate`, either flow: `HintPatchClient::apply_delta` (client-hint-patch) or `RewindClient::accumulate_delta` + `decode` (client-rewind, response rewind — `docs/rewind-client-mode.md`) |
| `IKPIR.Setup(DB)` | offline phase, all `d` segments | `IkpirServer::new` + `IkpirServer::setup` → `ServerSetupBundle` |
| (same, computed across cores) | identical output, untimed preamble | `IkpirServer::new_parallel` / `RewindClient::from_setup_parallel` / `HintPatchClient::from_setup_parallel` — see `ParallelSetupBackend` |
| `IKPIR.Query / Answer / Recover` | keyword online phase | `{RewindClient,HintPatchClient}::build_query` / `IkpirServer::answer` / `{RewindClient,HintPatchClient}::decode` |
| transcript `trans = (S_j)` | sparse per-segment overwrites; specified byte encoding | `HintDeltaBundle`, `SegmentRowDeltas`, `docs/hint-delta-wire-format.md` |
| hint `H = A·D` | client preprocessing material | `B::Hint` (`FrodoHint` / `SimpleHint`) |
| `A` (expanded from seed `β`) | public LWE matrix, never on the wire | `B::HintMaterial`, `expand_hint_material` |
| `n` | LWE dimension | `lwe_dim` (1566 FrodoPIR / 1275 SimplePIR) |
| `q = 2³²` | ciphertext modulus | native `u32` wraparound |
| `p = 2^pb` | plaintext modulus | `plaintext_bits` |
| `Δ = q/p` | plaintext↔ciphertext scaling | `round_p_to_q` / `round_q_to_p` |
| `χ_s, χ_e` | secret / error distributions | `sample_ternary_into` (FrodoPIR); `sample_uniform_zq_into` + `sample_discrete_gaussian_into` (SimplePIR) |
| `(ρ, ω)` reshape | per-segment matrix shape | FrodoPIR: identity `(n_rows, row_width)`; SimplePIR: near-square via `reshape_dims` |
| row-level / entry-level patch (Fig. 7) | hint-patch realizations | `HintPatchMode::RowLevel` / `HintPatchMode::EntryLevel` (default) |

One caveat on the letter `δ`/`Δ`: the paper uses `Δ = q/p` for the LWE
scaling, `δ` for correctness-failure probability, and the code additionally
uses "delta" for sparse hint patches (`HintDeltaBundle`, `row_deltas`). The
table above is the disambiguation.

## Benches

The PIR evaluation is thirteen focused, `clap`-parsed, CSV-emitting benches —
four in `ikpir-server`, nine in `ikpir-client` — each measuring one criterion
at one config and appending one row (the mutation benches append one row per
`(patch mode, kind)` for client-hint-patch, one per `kind` for client-rewind).
The client flow (client-hint-patch vs client-rewind) is always a separate
binary, never a runtime flag, and **benchmark data of the two flows is always
written to separate CSV files and never merged**; `client_query` and
`headtohead_query` are the only client-side benches that don't come in a
per-flow pair, because `build_query` is identical code on both flows:

| Crate | Benches |
|---|---|
| `ikpir-server` | `server_setup`, `server_answer`, `server_mutation`, `headtohead_answer` |
| `ikpir-client` | `client_query`, `client_hint_patch_decode`, `client_rewind_decode`, `client_hint_patch_mutation`, `client_rewind_mutation`, `client_rewind_staleness`, `headtohead_query`, `headtohead_hint_patch_decode`, `headtohead_rewind_decode` |

The `headtohead_*` benches fix the **keyword count** (`--num-keys`) and report
the DB size each scheme needed — the fair-comparison setting vs ChalametPIR /
Hao et al. 2025; the others fix the DB geometry and populate to `TableFull`
(or to `--load-factor` for the mutation benches). The `segmented-cuckoo` crate
adds eight filter / KV-store benches — five `cuckoo_filter_*`
(`load_factor`, `insert_throughput`, `lookup_throughput`, `delete_throughput`,
`false_positive_rate`) and three `kv_store_*`. Their flags are all optional:
with none, each runs the paper's **Table 2** matrix (five `(arity, bucket_size)`
pairs, `fingerprint_bits = 64`, `max_kicks = 2500`, ~10⁶ buckets), defined once
in `crates/segmented-cuckoo/benches/configs.rs`.

### Run one bench at one config

`scripts/bench.sh` runs a single bench at a single config, auto-deriving
`--plaintext-bits` (the max the backend's noise budget admits at `q = 2^32`)
and `--lwe-dim`, and writing the CSV under `results/<crate>/`:

```bash
./scripts/bench.sh server_answer --arity 4 --num-buckets 65536 --bucket-size 4 --value-bits 8192
./scripts/bench.sh client_hint_patch_decode --backend simple
./scripts/bench.sh client_rewind_decode --backend simple
./scripts/bench.sh server_mutation --patch-mode entry,row
./scripts/bench.sh headtohead_answer --arity 4 --num-buckets 262144 --num-keys 1000000
./scripts/bench.sh cuckoo_filter_insert_throughput               # all five Table 2 configs
./scripts/bench.sh cuckoo_filter_insert_throughput --arity 4 --bucket-size 2   # one cell
./scripts/bench.sh                              # -h: full flag + bench list
```

All flags are optional — for the PIR benches, omitted geometry falls back to a
small **dev-scale** config (~2¹⁶ slots, sub-second), *not* the paper's; for the
`segmented-cuckoo` benches, to the paper's Table 2 matrix. To run the paper's
PIR geometry, use the table sweeps below rather than this one-off runner.

### Reproduce a paper table

Per paper, with the flow and output file for every table: [`REPRODUCIBILITY.md`](REPRODUCIBILITY.md).

One sweep per table. Each resolves the paper's config matrix, then loops
`bench.sh` over it — so a table is one command, not twenty:

| Script | Table | Benches behind it |
|---|---|---|
| `scripts/table2.sh` | filter: load factor + insert/lookup/delete throughput, SCF vs standard | the four `cuckoo_filter_*` |
| `scripts/table3.sh` | online: query / response / answer latency | `headtohead_answer`, `headtohead_query` (common) + `headtohead_{hint_patch,rewind}_decode` (selected flow) |
| `scripts/table4.sh` | mutation throughput (insert/update/delete) | `server_mutation` (common) + `client_{hint_patch,rewind}_mutation` (selected flow) |
| `scripts/table5.sh` | setup: the static rebuild cost table 4 replaces | `server_setup` |

`table2.sh` forwards any flags to each bench; `table{3,4,5}.sh` additionally
accept `--arity` / `--bucket-size` / `--value-bits` / `--backend` to narrow the
matrix, and forward anything else. `table3.sh` and `table4.sh` additionally
accept `--flow client-hint-patch|client-rewind|all` (default `all`) to pick
which flow's leg runs; the common (flow-independent) legs always run once,
and — like every other benchmark data in this repo — the two flows' rows land
in separate CSV files, never merged:

```bash
./scripts/table2.sh                              # the full published table (~1-2 h)
./scripts/table2.sh --arity 4                    # just the arity-4 rows
./scripts/table4.sh                              # all 5 configs × 2 widths × 2 backends, both flows
./scripts/table4.sh --flow client-hint-patch     # camera-ready's HintUpdate column only
./scripts/table3.sh --arity 3 --flow client-rewind   # full-paper arity-3 cells, one flow
./scripts/table5.sh --backend frodo               # setup: RisePIR-F rows only
```

The PIR matrix (`PAPER_*` in `scripts/lib.sh`) is the single source of truth for
what those three sweep, mirroring what `benches/configs.rs` is for Table 2. A
bare `bench.sh` is *not* affected by it — that stays dev-scale on purpose.

### Quick smoke / correctness check

`scripts/smoke.sh` runs every PIR bench at a tiny config on both backends in a
couple of minutes, exercising the full setup → answer → query → decode →
mutation path (each decode bench self-checks with `verify_decode`) — the
"test the properties on small configs" path:

```bash
./scripts/smoke.sh                              # frodo + simple
IKPIR_SMOKE_BACKENDS=frodo ./scripts/smoke.sh   # one backend
cargo test -p segmented-cuckoo                  # filter / KV-store properties, fast
```

### Plaintext-bits and the paper config matrix

`bench.sh` sets `plaintext_bits` per `(backend, SCF geometry, value_bits)` by
targeting an explicit per-cell decode-failure budget
`δ_cell ≤ 2⁻⁴¹ / (arity · row_width)` — half the paper's overall `κ = 40`
correctness target (Lemma 2, corrected), union-bounded over the `row_width`
cells each of the `arity` per-segment reads returns. FrodoPIR evaluates its
uniform-ternary error's exact Bernstein tail against that budget (replacing
the old paper Eq. 8, `q ≥ 8·p²·√m`); SimplePIR retargets its Theorem C.1 bound
— adjusted for uncentered cells and the near-square reshape,
`q/p ≥ 2√2·σ·√ln(2/δ_cell)·p·√R` (σ = 6.4) — from a fixed `δ = 2⁻⁴⁰` to the
same per-config `δ_cell`. Both backends now depend on the full per-segment
geometry, including `fingerprint_bits`, not only `segment_rows` (FrodoPIR) or
`(segment_rows, value_bits)` (SimplePIR). The single source of truth is
`ikpir_common::pir_params` (full derivation in its module docs), exposed by
the `max_plaintext_bits` example that `scripts/lib.sh` shells out to; the
chosen `pb` appears as a CSV column. The `#[ignore]`d `noise_margin` tests
validate these operating points empirically:

```bash
cargo test -p ikpir-common --release -- --ignored noise_margin --nocapture
```

The paper evaluates five `(arity, bucket_size)` KV-SCF shapes × 2 value widths ×
2 backends. Each shape runs at one size, defined once by `paper_num_buckets` in
`scripts/lib.sh`:

| arity `d` | bucket_size `b` | num_buckets `n_b` | slots `N = n_b·b` | online keys `m` |
|---|---|---|---|---|
| 2 | 4 | 262144 = 2¹⁸ | 1 048 576 = 2²⁰ | 10⁶ |
| 4 | 1 | 1048576 = 2²⁰ | 1 048 576 = 2²⁰ | 10⁶ |
| 4 | 2 | 524288 = 2¹⁹ | 1 048 576 = 2²⁰ | 10⁶ |
| 3 | 2 | 786432 = 3·2¹⁸ | 1 572 864 = 3·2¹⁹ | 1 415 577 (fill 0.90) |
| 3 | 3 | 393216 = 3·2¹⁷ | 1 179 648 = 9·2¹⁷ | 1 061 683 (fill 0.90) |

The three arity-2/4 shapes share `N = 2²⁰`, so they differ only in shape, and
the online table fixes `m = 10⁶` — the count ChalametPIR and KPIR^index publish
at, filling those tables to 0.954, under every achieved load factor of Table 2.

Arity 3 is a **full-paper addition** and does not appear in the submitted
version. It cannot reach `N = 2²⁰`: a segmented 3-ary table needs `n_b = 3·2^t`,
so `N = 3·2^t·b` lands on a coarser ladder. Each arity-3 shape takes the
smallest rung still holding 10⁶ keys at fill 0.90 (one rung down gives 707 k
slots for (3,2), 531 k for (3,3) — both short), and reports at that fill rather
than at a fixed `m`, having no baseline to line up against. It is covered by
`table3.sh` and `table4.sh`, but not by `table5.sh`.

Value widths: `--value-bits 2048 / 8192` (256 B / 1 kB). The mutation and setup
tables seed to fill 0.90; mutation applies one batch of τ = 1 % of the slots
(10 485 at `N = 2²⁰`). Narrower values (e.g. `--value-bits 256` = 32 B) still
run — they are simply not a paper config.

### Low-level: `cargo bench` directly

`bench.sh` is a thin wrapper; the benches also run standalone (results land in
the crate-local `results/` unless `IKPIR_RESULTS_DIR` is set). `--plaintext-bits`
then defaults to `8` (safe everywhere, but below each backend's max):

```bash
cargo bench -p ikpir-server --bench server_answer -- --backend simple --plaintext-bits 10
cargo bench -p segmented-cuckoo --bench cuckoo_filter_false_positive_rate
```

CSVs land under `results/<crate>/` (`results/ikpir-server/`,
`results/ikpir-client/`, `results/segmented-cuckoo/`); the directory is
git-ignored and regenerated on demand.

Paper numbers were measured on the machine described in
[`docs/server-specs.txt`](docs/server-specs.txt).

## License

Licensed under the Apache License, Version 2.0 ([LICENSE](LICENSE)).
Copyright and attribution are recorded in [NOTICE](NOTICE).

Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion in the work by you, as defined in the Apache-2.0 license, shall
be licensed as above, without any additional terms or conditions.
