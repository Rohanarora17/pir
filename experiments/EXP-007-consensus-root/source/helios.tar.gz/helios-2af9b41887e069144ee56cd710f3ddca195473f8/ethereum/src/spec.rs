use alloy::{
    consensus::{transaction::SignerRecoverable, Transaction as _},
    primitives::keccak256,
};
use std::{collections::HashMap, sync::Arc};

use alloy::{
    consensus::{
        proofs::{calculate_transaction_root, calculate_withdrawals_root},
        Receipt, ReceiptWithBloom, TxReceipt, TxType, TypedTransaction,
    },
    eips::{BlockId, Encodable2718},
    network::{
        BuildResult, Network, NetworkTransactionBuilder, NetworkWallet, TransactionBuilder,
        TransactionBuilderError,
    },
    primitives::Address,
    rpc::types::{state::StateOverride, Log, TransactionRequest},
};
use async_trait::async_trait;
use revm::context::result::{ExecutionResult, HaltReason};

use helios_common::{
    execution_provider::ExecutionProvider,
    fork_schedule::ForkSchedule,
    network_spec::{has_valid_header_field_order, NetworkSpec},
    types::{Account, EvmError},
};

use crate::evm::EthereumEvm;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Ethereum;

#[cfg_attr(not(target_arch = "wasm32"), async_trait)]
#[cfg_attr(target_arch = "wasm32", async_trait(?Send))]
impl NetworkSpec for Ethereum {
    type HaltReason = HaltReason;

    fn encode_receipt(receipt: &Self::ReceiptResponse) -> Vec<u8> {
        let tx_type = receipt.transaction_type();
        let receipt = receipt.inner.as_receipt_with_bloom().unwrap();
        let logs = receipt
            .logs()
            .iter()
            .map(|l| l.inner.clone())
            .collect::<Vec<_>>();

        let consensus_receipt = Receipt {
            cumulative_gas_used: receipt.cumulative_gas_used(),
            status: receipt.status_or_post_state(),
            logs,
        };

        let rwb = ReceiptWithBloom::new(consensus_receipt, receipt.bloom());
        let encoded = alloy::rlp::encode(rwb);

        match tx_type {
            TxType::Legacy => encoded,
            _ => [vec![tx_type as u8], encoded].concat(),
        }
    }

    fn encode_transaction(tx: &Self::TransactionResponse) -> Vec<u8> {
        tx.inner.encoded_2718()
    }

    fn is_hash_valid(block: &Self::BlockResponse) -> bool {
        if !has_valid_header_field_order(&block.header.inner)
            || block.header.hash_slow() != block.header.hash
        {
            return false;
        }

        let Some(txs) = block.transactions.as_transactions() else {
            return false;
        };
        if calculate_transaction_root(&txs.iter().map(|t| t.clone().inner).collect::<Vec<_>>())
            != block.header.transactions_root
        {
            return false;
        }

        let withdrawals_root = block
            .withdrawals
            .as_ref()
            .map(|withdrawals| calculate_withdrawals_root(withdrawals));
        if withdrawals_root != block.header.withdrawals_root {
            return false;
        }

        block.uncles.is_empty()
    }

    fn validate_block(block: &mut Self::BlockResponse, full_tx: bool) -> bool {
        if !Self::is_hash_valid(block) {
            return false;
        }
        let alloy::rpc::types::BlockTransactions::Full(txs) = &mut block.transactions else {
            return false;
        };
        if full_tx {
            for (index, tx) in txs.iter_mut().enumerate() {
                // Neither the cached hash nor recovered sender is authenticated by the trie root.
                if keccak256(tx.inner.encoded_2718()) != *tx.inner.tx_hash()
                    || tx.inner.inner().recover_signer().ok() != Some(tx.inner.signer())
                    || tx.block_hash != Some(block.header.hash)
                    || tx.block_number != Some(block.header.number)
                    || tx.transaction_index != Some(index as u64)
                {
                    return false;
                }
                tx.effective_gas_price =
                    Some(tx.inner.effective_gas_price(block.header.base_fee_per_gas));
                tx.block_timestamp = Some(block.header.timestamp);
            }
        } else {
            // Cached RPC hashes are not committed by the transaction trie. Derive
            // the only transaction field exposed by this response from signed bytes.
            block.transactions = alloy::rpc::types::BlockTransactions::Hashes(
                txs.iter()
                    .map(|tx| keccak256(Self::encode_transaction(tx)))
                    .collect(),
            );
        }
        block.header.total_difficulty = None;
        block.header.size = None;
        block.uncles.is_empty()
    }

    fn receipt_contains(list: &[Self::ReceiptResponse], elem: &Self::ReceiptResponse) -> bool {
        for receipt in list {
            if receipt == elem {
                return true;
            }
        }

        false
    }

    fn receipt_logs(receipt: &Self::ReceiptResponse) -> Vec<Log> {
        receipt.inner.logs().to_vec()
    }

    fn receipt_metadata_valid(
        receipt: &Self::ReceiptResponse,
        tx: &Self::TransactionResponse,
        block: &Self::BlockResponse,
        forks: &ForkSchedule,
    ) -> bool {
        let contract_address = tx.is_create().then(|| tx.inner.signer().create(tx.nonce()));
        let blob_gas_used = tx.blob_gas_used();
        let blob_gas_price = blob_gas_used.and_then(|_| {
            block.header.excess_blob_gas.map(|excess| {
                alloy::eips::eip4844::fake_exponential(
                    1,
                    excess as u128,
                    forks.get_blob_base_fee_update_fraction(block.header.timestamp) as u128,
                )
            })
        });
        receipt.contract_address == contract_address
            && receipt.effective_gas_price == tx.effective_gas_price(block.header.base_fee_per_gas)
            && receipt.blob_gas_used == blob_gas_used
            && receipt.blob_gas_price == blob_gas_price
    }

    async fn transact<E: ExecutionProvider<Self>>(
        tx: &Self::TransactionRequest,
        validate_tx: bool,
        execution: Arc<E>,
        chain_id: u64,
        fork_schedule: ForkSchedule,
        block_id: BlockId,
        state_overrides: Option<StateOverride>,
    ) -> Result<(ExecutionResult, HashMap<Address, Account>), EvmError> {
        let mut evm = EthereumEvm::new(execution, chain_id, fork_schedule, block_id);

        evm.transact_inner(tx, validate_tx, state_overrides).await
    }
}

impl Network for Ethereum {
    type TxType = alloy::consensus::TxType;
    type TxEnvelope = alloy::consensus::TxEnvelope;
    type UnsignedTx = alloy::consensus::TypedTransaction;
    type ReceiptEnvelope = alloy::consensus::ReceiptEnvelope;
    type Header = alloy::consensus::Header;
    type TransactionRequest = alloy::rpc::types::TransactionRequest;
    type TransactionResponse = alloy::rpc::types::Transaction;
    type ReceiptResponse = alloy::rpc::types::TransactionReceipt;
    type HeaderResponse = alloy::rpc::types::Header;
    type BlockResponse = alloy::rpc::types::Block<Self::TransactionResponse, Self::HeaderResponse>;
}

impl NetworkTransactionBuilder<Ethereum> for TransactionRequest {
    fn complete_type(&self, ty: TxType) -> Result<(), Vec<&'static str>> {
        match ty {
            TxType::Legacy => self.complete_legacy(),
            TxType::Eip2930 => self.complete_2930(),
            TxType::Eip1559 => self.complete_1559(),
            TxType::Eip4844 => self.complete_4844(),
            TxType::Eip7702 => self.complete_7702(),
        }
    }

    fn can_submit(&self) -> bool {
        // value and data may be None. If they are, they will be set to default.
        // gas fields and nonce may be None, if they are, they will be populated
        // with default values by the RPC server
        self.from.is_some()
    }

    fn can_build(&self) -> bool {
        // value and data may be none. If they are, they will be set to default
        // values.

        // chain_id and from may be none.
        let common = self.gas.is_some() && self.nonce.is_some();

        let legacy = self.gas_price.is_some();
        let eip2930 = legacy && self.access_list().is_some();

        let eip1559 = self.max_fee_per_gas.is_some() && self.max_priority_fee_per_gas.is_some();

        let eip4844 = eip1559 && self.sidecar.is_some() && self.to.is_some();
        common && (legacy || eip2930 || eip1559 || eip4844)
    }

    #[doc(alias = "output_transaction_type")]
    fn output_tx_type(&self) -> TxType {
        self.preferred_type()
    }

    #[doc(alias = "output_transaction_type_checked")]
    fn output_tx_type_checked(&self) -> Option<TxType> {
        self.buildable_type()
    }

    fn prep_for_submission(&mut self) {
        self.transaction_type = Some(self.preferred_type() as u8);
        self.trim_conflicting_keys();
        self.populate_blob_hashes();
    }

    fn build_unsigned(self) -> BuildResult<TypedTransaction, Ethereum> {
        if let Err((tx_type, missing)) = self.missing_keys() {
            return Err(
                TransactionBuilderError::InvalidTransactionRequest(tx_type, missing)
                    .into_unbuilt(self),
            );
        }
        Ok(self.build_typed_tx().expect("checked by missing_keys"))
    }

    async fn build<W: NetworkWallet<Ethereum>>(
        self,
        wallet: &W,
    ) -> Result<<Ethereum as Network>::TxEnvelope, TransactionBuilderError<Ethereum>> {
        Ok(wallet.sign_request(self).await?)
    }
}
